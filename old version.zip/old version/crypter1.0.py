import time
time.sleep(0.3)
print('************************************')
time.sleep(0.3)
print('*                                  *')
time.sleep(0.3)
print('*   Welcome to crypter1.0          *')
time.sleep(0.3)
print('*   Create by Apinut Chompoonuch   *')
time.sleep(0.3)
print('*   Use "help" to see command      *')
time.sleep(0.3)
print('*                Be nice!          *')
time.sleep(0.3)
print('*                                  *')
time.sleep(0.3)
print('************************************')

while True:
    inp = input('>>')
    key = str(inp).strip()
    if key == 'help':
        print('***Use these key to command***\n')
        print('find       To find word in long text                 md5        To hash text to Md5')
        print('rev        To reverse text                           tobi       To encode text to Binary')
        print('rep        To find and replace the text              frombi     To decode Binary from text')
        print('rot13      To rotate character(a-z,A-Z) in text      todec      To encode text to Decimal')
        print('rot47      To rotate all character in text           fromdec    To decode Deciaml from text')
        print('alp        To turn Alphabet to number                tohex      To encode text to Hexadecimal')
        print('arb        To turn Arabic number to alphabet         fromhex    To decode Hexadeciaml from text')
        print('upc        To turn text to uppercase                 tob64      To encode text to Base64')
        print('lwc        To turn text to lowercase                 fromb64    To decode Base64 from text')
        print('tomos      To encode text to Morse Code')
        print('frommos    To decode Morse Code from text')
        print('\nexit       To end this program')
    elif key == 'rep':
        text = input('Enter the text\n>>')
        fin = input('Enter word that you find\n>>')
        rep = input('Enter word that you replace\n>>')
        text = text.replace(fin,rep)
        print(text)
    elif key == 'md5':
        import hashlib
        text = input('Enter the text to hash\n>>')
        hash_key = hashlib.md5(str(text).strip().encode())
        key_checker = str(hash_key.hexdigest())
        print(key_checker)
    elif key == 'tohex':
        text = input('Enter the text to encode\n>>')
        for char in text:
            byte_array = char.encode('utf-8')
            print(byte_array.hex(),end = ' ')
        print('')
    elif key == 'fromhex':
        text = input('Enter the Hex to decode\n>>')
        word = text.split(' ')
        try:
            for i in word:
                outp = bytes.fromhex(i).decode('utf-8')
                print(outp,end = '')
        except ValueError as e:
            print('Error decode!!!\nPlease enter Hexadecimal',end = '')
        print('')
    elif key == 'tobi':
        text = input('Enter the text to encode\n>>')
        for char in text:
            byte_array = char.encode()
            bi_int = int.from_bytes(byte_array,'big')
            bi_str = bin(bi_int)
            print((bi_str[0]+bi_str[2:]),end = ' ')
        print('')
    elif key == 'frombi':
        text = input('Enter the Binary to decode\n>>')
        word = text.split(' ')
        try:
            for i in word:
                bi_int = int(i,2)
                byte_num = bi_int.bit_length() + 7//8
                bi_array = bi_int.to_bytes(byte_num,'big')
                outp = bi_array.decode()
                print(outp[-1],end = '')
        except ValueError as e:
            print('Error decode!!!\nPlease enter Binary',end = '')
        print('')
    elif key == 'tob64':
        import base64
        text = input('Enter the text to encode\n>>')
        hash_key = base64.b64encode(str(text).encode('utf-8'))
        key_checker = str(hash_key,'utf-8')
        print(key_checker)
    elif key == 'fromb64':
        import base64
        text = input('Enter the Base64 to decode\n>>')
        try:
            hash_key = base64.b64decode(text.encode('ascii'))
            key_checker = str(hash_key,'ascii')
            print(key_checker)
        except NameError as e:
            print('Error decode!!!\nPlease enter Base64')
        except UnicodeDecodeError as e:
            print('Error decode!!!\nPlease enter Base64')
        except base64.binascii.Error as e:
            print('Error decode!!!\nPlease enter Base64')
    elif key == 'todec':
        text = input('Enter the text to Decimal\n>>')
        outp = ''
        for i in text:
            dec_i = ord(i)
            x = (str(dec_i) + ',')
            outp = outp+x
        print(outp[0:-1])
    elif key == 'fromdec':
        text = input('Enter the Decimal to word(seperate by ",")\n>>')
        word = text.split(',')
        try:
            for i in word:
                i = int(i)
                print(chr(i),end = '')
        except ValueError as e:
            print('Error decode!!!\nPlease enter Decimal',end = '')
        print('')
    elif key == 'rev':
        text = input('Enter the text to reverse\n>>')
        text_rev = ''
        i = (len(text) - 1)
        while i >= 0:
            text_rev = text_rev + text[i]
            i-=1
        print(text_rev)
    elif key == 'rot47':
        text = input('Enter the text to rotate\n>>')
        rot = input('Enter amout of rotation or "all" to see all rotation\n>>')
        chrlst = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','[','\\',']','^','_','`','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','{','|','}','~','!','"','#','$','%','&',"'",'(',')','*','+',',','-','.','/','0','1','2','3','4','5','6','7','8','9',':',';','<','=','>','?','@']
        if rot == 'all':
            for rot in range(len(chrlst)):
                new_text = ''
                for i in range (len(text)):
                    for j in range (len(chrlst)):
                        while (j + rot) >= len(chrlst):
                            rot = rot - len(chrlst)
                        if text[i] == chrlst[j]:
                            new_text = new_text + chrlst[j+rot]
                    if text[i] not in chrlst:
                        new_text = new_text + text[i]
                print(new_text)
        else:
            try:
                rot = int(rot)
                new_text = ''
                for i in range (len(text)):
                    for j in range (len(chrlst)):
                        while (j + rot) >= len(chrlst):
                            rot = rot - len(chrlst)
                        if text[i] == chrlst[j]:
                            new_text = new_text + chrlst[j+rot]
                    if text[i] not in chrlst:
                        new_text = new_text + text[i]
                print(new_text)
            except ValueError as e:
                print('Error rotate!!!\nPlease enter number for amount')
    elif key == 'rot13':
        text = input('Enter the text to rotate\n>>')
        rot = input('Enter amout of rotation or "all" to see all rotation\n>>')
        x = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
        X = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
        if rot == 'all':
            for rot in range(26):
                new_text = ''
                for i in range (len(text)):
                    for j in range (len(x)):
                        while (j + rot) >= 26:
                            rot = rot - 26
                        if text[i] == x[j]:
                            new_text = new_text + x[j+rot]
                    for k in range (len(X)):
                        while (k + rot) >= 26:
                            rot = rot - 26
                        if text[i] == X[k]:
                            new_text = new_text + X[k+rot]
                    if text[i] not in x:
                        if text[i] not in X:
                            new_text = new_text + text[i]
                print(new_text)
        else:
            try:
                rot = int(rot)
                new_text = ''
                for i in range (len(text)):
                    for j in range (len(x)):
                        while (j + rot) >= 26:
                            rot = rot - 26
                        if text[i] == x[j]:
                            new_text = new_text + x[j+rot]
                    for k in range (len(X)):
                        while (k + rot) >= 26:
                            rot = rot - 26
                        if text[i] == X[k]:
                            new_text = new_text + X[k+rot]
                    if text[i] not in x:
                        if text[i] not in X:
                            new_text = new_text + text[i]
                print(new_text)
            except ValueError as e:
                print('Error rotate!!!\nPlease enter number for amount')
    elif key == 'alp':
        text = input('Enter the Alphabet to number\n>>')
        text = text.lower()
        text = text.replace('','-')
        for char in text:
            if char in ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']:
                rep = str(ord(char)-96)
                text = text.replace(char,rep.zfill(2))
        print(text[1:-1])
    elif key == 'arb':
        text = input('Enter the Arabic number to Alphabet(seperate by "-")\n>>')
        word = text.split('-')
        for char in word:
            try:
                if char in ['01','02','03','04','05','06','07','08','09']:
                    ord_char = int(char[1])+96
                    text = text.replace(char,chr(ord_char))
                elif int(char) in range (10,26):
                    ord_char = int(char)+96
                    text = text.replace(char,chr(ord_char))
            except ValueError as e:
                pass
        text = text.replace('-','')
        print(text)
    elif key == 'upc':
        text = input('Enter the text to uppercase\n>>')
        print(text.upper())
    elif key == 'lwc':
        text = input('Enter the text to lowercase\n>>')
        print(text.lower())
    elif key == 'find':
        print('Enter the long text(key "end" when finish)\n>>',end = '')
        lines = {}
        position = 0
        while True:
            text = input()
            if text == 'end':
                break
            else:
                position = position + 1
                seq = str(position)
                lines[text] = (seq)
        wrdlst = []
        word = input('Enter the word you find\n>>')
        for wrd in lines:
            sin_wrd = wrd.split(' ')
            for i in sin_wrd:
                if word in i:
                    print(('line ' + lines[wrd]),end = '')
                    print('\t\t',i)
        for i in range(5):
            print('.',end = '')
            time.sleep(0.2)
        print('\nFinish finding')
    elif key == 'tomos':
        text = input('Enter the text to encode\n>>')
        text = text.upper()
        morse = { 'A':'.-', 'B':'-...', 'C':'-.-.', 'D':'-..', 'E':'.', 'F':'..-.', 'G':'--.', 'H':'....', 'I':'..', 'J':'.---', 'K':'-.-', 'L':'.-..', 'M':'--', 'N':'-.', 'O':'---', 'P':'.--.', 'Q':'--.-', 'R':'.-.', 'S':'...', 'T':'-', 'U':'..-', 'V':'...-', 'W':'.--', 'X':'-..-', 'Y':'-.--', 'Z':'--..', '1':'.----', '2':'..---', '3':'...--','4':'....-', '5':'.....', '6':'-....', '7':'--...', '8':'---..', '9':'----.', '0':'-----', ', ':'--..--', '.':'.-.-.-', '?':'..--..', '/':'-..-.', '-':'-....-', '(':'-.--.', ')':'-.--.-'}
        lst = []
        for x in morse:
            lst.append(x)
        for i in range (len(text)):
            char = text[i]
            if char in lst:
                print(morse[char],end = ' ')
            else:
                print(char,end = ' ')
        print('')
    elif key == 'frommos':
        text = input('Enter the Morse Code to decode\n>>')
        morse = { 'A':'.-', 'B':'-...', 'C':'-.-.', 'D':'-..', 'E':'.', 'F':'..-.', 'G':'--.', 'H':'....', 'I':'..', 'J':'.---', 'K':'-.-', 'L':'.-..', 'M':'--', 'N':'-.', 'O':'---', 'P':'.--.', 'Q':'--.-', 'R':'.-.', 'S':'...', 'T':'-', 'U':'..-', 'V':'...-', 'W':'.--', 'X':'-..-', 'Y':'-.--', 'Z':'--..', '1':'.----', '2':'..---', '3':'...--','4':'....-', '5':'.....', '6':'-....', '7':'--...', '8':'---..', '9':'----.', '0':'-----', ', ':'--..--', '.':'.-.-.-', '?':'..--..', '/':'-..-.', '-':'-....-', '(':'-.--.', ')':'-.--.-'}
        word = text.split(' ')
        for x in word:
            if x in morse.values():
                for char in morse:
                    if x == morse[char]:
                        print(char,end = '')
            else:
                print(x,end = '')
        print('')
    elif key == 'exit':
        print('closing',end = '')
        time.sleep(0.3)
        for i in range(3):
            time.sleep(0.3)
            print('.',end = '')
        break
    elif key == 'hello':
        print('Hello!!!\nKey "help" to see command')
    else:
        print('Found no command!!!\nTry to use "help" to see command')
